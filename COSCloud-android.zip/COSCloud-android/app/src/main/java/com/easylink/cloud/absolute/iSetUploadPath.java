package com.easylink.cloud.absolute;

public interface iSetUploadPath {
    void setPath(String path);
}
