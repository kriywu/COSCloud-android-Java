package com.easylink.cloud.absolute;

public interface iFlashData {
    void flash();
}
