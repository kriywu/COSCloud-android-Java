package com.easylink.cloud.modle;

public class Bucket {
    private String name;
    private String region;


}
