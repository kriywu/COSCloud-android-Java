package com.easylink.cloud.absolute;

public interface ProgressCallback {
    void setProgress(float x);
}
